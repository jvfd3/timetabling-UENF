// index.js
import {createDbConnection} from "./db.js";

let local = "aws>lambda>professores>delete";

/*

aws lambda create-function --function-name professoresRead --runtime nodejs20.x --role arn:aws:iam::375423677214:role/LambdaRole --handler index.handler --zip-file fileb://D:/HDExt/GitHub/UENF/9Semestre/timetabling-UENF/Files/AWS/lambdas/createProfessor/createProfessor.zip --environment "Variables={DB_HOST='dbtimetabling.cgsgwtemx5r8.us-east-2.rds.amazonaws.com',DB_USER='tang',DB_PASSWORD='annabell',DB_NAME='timetabling'}"
*/

async function defaultDelete(query, id) {
  try {
    let dbConnection = await createDbConnection();
    await dbConnection.execute(query, [id]);
    await dbConnection.end();
    let successMessage = local + ">defaultDelete, id:" + id + " deletado com sucesso";
    console.log(successMessage);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: successMessage}),
    };
  } catch (error) {
    let errorMessage = local + ">defaultDelete>Erro ao executar a query:"
    console.error(errorMessage, error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: errorMessage }),
    };
  }
}

async function deleteProfessor(id) {
  const q = "DELETE FROM professores WHERE idprofessor = ?";
  return await defaultDelete(q, id);
}

async function handler(event) {
  console.log(local + ">handler:", event);
  return await deleteProfessor(event.pathParameters.id);
}

export { handler };