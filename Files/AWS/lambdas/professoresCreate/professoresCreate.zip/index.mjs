// index.js
import {createDbConnection} from "./db.js";

let local = "aws>lambda>professores>delete";

/*
aws lambda create-function --function-name professoresDelete --runtime nodejs20.x --role arn:aws:iam::375423677214:role/LambdaRole --handler index.handler --zip-file fileb://D:/HDExt/GitHub/UENF/9Semestre/timetabling-UENF/Files/AWS/lambdas/professoresDelete/professoresDelete.zip --environment "Variables={DB_HOST='dbtimetabling.cgsgwtemx5r8.us-east-2.rds.amazonaws.com',DB_USER='tang',DB_PASSWORD='annabell',DB_NAME='timetabling'}"
*/
async function defaultCreate(query, queryValues) {
  try {
    let dbConnection = await createDbConnection();
    await dbConnection.execute(query, queryValues);
    await dbConnection.end();
    let successMessage = local + ">defaultCreate, professor criado com sucesso";
    console.log(successMessage);
    return {
      statusCode: 201,
      body: JSON.stringify({ message: successMessage}),
    };
  } catch (error) {
    let errorMessage = local + ">defaultCreate>Erro ao executar a query:"
    console.error(errorMessage, error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: errorMessage }),
    };
  }
}

function convertToList(professor) {
  const values = [
    professor.apelidoProfessor,
    professor.curso,
    professor.laboratorio,
    professor.nomeProfessor,
  ];
  return values;
}

async function createProfessor(professor) {
  let createProfessorQuery = "INSERT INTO professores(`apelidoProfessor`, `curso`, `laboratorio`, `nomeProfessor`) VALUES(?, ?, ?, ?)";
  return await defaultCreate(createProfessorQuery, convertToList(professor));
}

async function handler(event) {
  console.log(local + ">handler:", event);
  // const event = JSON.parse(event.body);
  return await createProfessor(event);
}

export { handler };