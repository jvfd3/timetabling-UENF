// index.js
import {dbConnection} from "./db.js";

let local = "aws>lambda>professores>read";

/*

aws lambda create-function --function-name professoresRead --runtime nodejs20.x --role arn:aws:iam::375423677214:role/LambdaRole --handler index.handler --zip-file fileb://D:/HDExt/GitHub/UENF/9Semestre/timetabling-UENF/Files/AWS/lambdas/createProfessor/createProfessor.zip --environment "Variables={DB_HOST='dbtimetabling.cgsgwtemx5r8.us-east-2.rds.amazonaws.com',DB_USER='tang',DB_PASSWORD='annabell',DB_NAME='timetabling'}"
*/

async function defaultRead(query) {
  try {
    const [rows, _] = await dbConnection.execute(query);
    await dbConnection.end();
    console.log(local + ">defaultRead, rows:", rows)
    return {
      statusCode: 200,
      body: JSON.stringify(rows),
    };
  } catch (error) {
    console.error(local + ">defaultRead>Erro ao executar a query:", error)
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Erro ao executar a query' }),
    };
  }
}

function readProfessores() {
  const q = "SELECT * FROM professores";
  return defaultRead(q);
}

async function handler(event) {
  console.log(local + ">handler:", event);
  return readProfessores();
}

export { handler };