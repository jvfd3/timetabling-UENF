""" Lambda Function to retrieve professores from RDS """

import json
import boto3

rds_client = boto3.client('rds-data')

database_name = 'timetabling'
db_cluster_arn = 'arn:aws:rds:us-east-2:375423677214:cluster:dbtimetabling'
db_credentials_secrets_store_arn = 'arn:aws:secretsmanager:us-east-2:375423677214:secret:timetablingSecrets-5dR6rH'
def lambda_handler(event, context):
    """ Lambda Handler """
    statement = "SELECT * FROM timetabling.professores"
    response = execute_statement(sql=statement)
    return response

def execute_statement(sql):
    """ Execute SQL? """
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql
    )
    return response
